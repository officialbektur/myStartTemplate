// Подключение функционал
import { isMobile } from "./files/functions.js";
// Подключение списка активных модулей
import { flsModules } from "./files/modules.js";
